# ACADEMIC BACKGROUND

[https://notionplus.dev/embed/icon?id=NDg](https://notionplus.dev/embed/icon?id=NDg)

I completed my schooling at **Amalorpavam Higher Secondary School**, Pondicherry, where I laid the foundation for my academic journey. During my time there:

- I achieved **75.3%** in my 10th-grade board exams.
- I excelled in my 12th-grade board exams, scoring **86.4%**.

Currently, I am pursuing a **B.Tech in Computer Science Engineering** at **Manakula Vinayagar Institute of Technology**, Pondicherry. With a strong commitment to my studies, I have maintained a commendable **CGPA of 8.5** in my current semester.

This academic path has equipped me with a solid understanding of computer science fundamentals, fostering my interests in cybersecurity, design, coding, and content creation. I look forward to continuing this journey of growth and innovation.

# **COURSE WORK**

Here is a comprehensive list of coursework typically included in a **Computer Science Engineering (CSE)** program. This list covers foundational, intermediate, and advanced subjects:

---

### **Core Computer Science Courses**

1. **Programming Fundamentals**
    - C, C++, Python, Java
2. **Data Structures and Algorithms**
    - Linked Lists, Trees, Graphs, Sorting and Searching Algorithms
3. **Computer Organization and Architecture**
    - Microprocessors, Assembly Language, Memory Hierarchy
4. **Operating Systems**
    - Process Management, File Systems, Deadlocks, Threads
5. **Database Management Systems (DBMS)**
    - SQL, Normalization, Transactions, Database Design
6. **Object-Oriented Programming**
    - Principles, OOP in C++/Java

---

### **Advanced and Specialized Courses**

1. **Computer Networks**
    - Protocols, OSI Model, Network Security
2. **Web Development**
    - HTML, CSS, JavaScript, Frameworks like React or Angular
3. **Cloud Computing**
- Virtualization, AWS, Azure, Kubernetes
1. **Artificial Intelligence and Machine Learning**
- Neural Networks, Algorithms, TensorFlow, NLP
1. **Cybersecurity**
- Cryptography, Ethical Hacking, Network Security
- Hadoop, Spark, Data Visualization
- Android, iOS, Flutter

---

### **Mathematics and Theoretical Foundations**

1. **Discrete Mathematics**
- Set Theory, Graph Theory, Logic
1. **Linear Algebra and Probability**
- Matrices, Eigenvalues, Probability Distributions
1. **Theory of Computation**
- Automata, Turing Machines, Formal Languages

---

### **Emerging Technologies**

1. **Blockchain Technology**
- Smart Contracts, Cryptographic Concepts
1. **Internet of Things (IoT)**

---