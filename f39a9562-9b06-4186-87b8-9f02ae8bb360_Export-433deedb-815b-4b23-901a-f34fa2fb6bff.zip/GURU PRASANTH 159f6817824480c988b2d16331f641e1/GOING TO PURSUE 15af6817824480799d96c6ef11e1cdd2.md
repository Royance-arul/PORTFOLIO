# GOING TO PURSUE

# GRAPHICAL DESIGN

[Figma: The Collaborative Interface Design Tool](https://www.figma.com/)

# CYBER SECURITY

[Kali Linux | Penetration Testing and Ethical Hacking Linux Distribution](https://www.kali.org/)

# AI IN NANOTECHNOLOGY

[Artificial Intelligence in Medicine - AIMed](https://ai-med.io/)